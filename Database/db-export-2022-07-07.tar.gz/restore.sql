--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.4 (Debian 10.4-2.pgdg90+1)
-- Dumped by pg_dump version 14.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE un;
--
-- Name: un; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE un WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE un OWNER TO postgres;

\connect un

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

--
-- Name: meeting; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.meeting (
    meeting_id character varying NOT NULL,
    topic character varying,
    full_text character varying,
    url character varying,
    date character varying,
    year integer,
    veto_used_in_meeting boolean
);


ALTER TABLE public.meeting OWNER TO admin;

--
-- Name: resolution; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.resolution (
    id integer NOT NULL,
    draft_id character varying,
    final_id character varying,
    draft_url character varying,
    final_url character varying,
    status character varying,
    draft_text character varying,
    final_text character varying,
    year integer,
    meeting_id character varying
);


ALTER TABLE public.resolution OWNER TO admin;

--
-- Name: resolution_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.resolution_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resolution_id_seq OWNER TO admin;

--
-- Name: resolution_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.resolution_id_seq OWNED BY public.resolution.id;


--
-- Name: state; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.state (
    state_id integer NOT NULL,
    name character varying
);


ALTER TABLE public.state OWNER TO admin;

--
-- Name: state_state_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.state_state_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.state_state_id_seq OWNER TO admin;

--
-- Name: state_state_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.state_state_id_seq OWNED BY public.state.state_id;


--
-- Name: vetocasts; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.vetocasts (
    vetoed_resolution character varying NOT NULL,
    state_id integer NOT NULL
);


ALTER TABLE public.vetocasts OWNER TO admin;

--
-- Name: resolution id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.resolution ALTER COLUMN id SET DEFAULT nextval('public.resolution_id_seq'::regclass);


--
-- Name: state state_id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.state ALTER COLUMN state_id SET DEFAULT nextval('public.state_state_id_seq'::regclass);


--
-- Data for Name: meeting; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.meeting (meeting_id, topic, full_text, url, date, year, veto_used_in_meeting) FROM stdin;
\.
COPY public.meeting (meeting_id, topic, full_text, url, date, year, veto_used_in_meeting) FROM '$$PATH$$/2883.dat';

--
-- Data for Name: resolution; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.resolution (id, draft_id, final_id, draft_url, final_url, status, draft_text, final_text, year, meeting_id) FROM stdin;
\.
COPY public.resolution (id, draft_id, final_id, draft_url, final_url, status, draft_text, final_text, year, meeting_id) FROM '$$PATH$$/2885.dat';

--
-- Data for Name: state; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.state (state_id, name) FROM stdin;
\.
COPY public.state (state_id, name) FROM '$$PATH$$/2882.dat';

--
-- Data for Name: vetocasts; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.vetocasts (vetoed_resolution, state_id) FROM stdin;
\.
COPY public.vetocasts (vetoed_resolution, state_id) FROM '$$PATH$$/2886.dat';

--
-- Name: resolution_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.resolution_id_seq', 2998, true);


--
-- Name: state_state_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.state_state_id_seq', 42, true);


--
-- Name: resolution draft_id_uc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.resolution
    ADD CONSTRAINT draft_id_uc UNIQUE (draft_id);


--
-- Name: meeting meeting_id_uc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.meeting
    ADD CONSTRAINT meeting_id_uc PRIMARY KEY (meeting_id);


--
-- Name: resolution resolution_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.resolution
    ADD CONSTRAINT resolution_pkey PRIMARY KEY (id);


--
-- Name: state state_name_uc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.state
    ADD CONSTRAINT state_name_uc UNIQUE (name);


--
-- Name: state state_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.state
    ADD CONSTRAINT state_pkey PRIMARY KEY (state_id);


--
-- Name: vetocasts vetoed_resolution_state_id_uc; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vetocasts
    ADD CONSTRAINT vetoed_resolution_state_id_uc PRIMARY KEY (vetoed_resolution, state_id);


--
-- Name: resolution resolution_meeting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.resolution
    ADD CONSTRAINT resolution_meeting_id_fkey FOREIGN KEY (meeting_id) REFERENCES public.meeting(meeting_id);


--
-- Name: vetocasts vetocasts_state_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vetocasts
    ADD CONSTRAINT vetocasts_state_id_fkey FOREIGN KEY (state_id) REFERENCES public.state(state_id);


--
-- Name: vetocasts vetocasts_vetoed_resolution_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.vetocasts
    ADD CONSTRAINT vetocasts_vetoed_resolution_fkey FOREIGN KEY (vetoed_resolution) REFERENCES public.resolution(draft_id);


--
-- PostgreSQL database dump complete
--

